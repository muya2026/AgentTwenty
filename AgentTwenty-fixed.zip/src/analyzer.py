"""
AgentAnalyzer - AI Analysis Module for AgentTwenty

This module uses the Qwen API (via OpenAI-compatible interface) to analyze
Moltbook posts and extract insights about tech opportunities, AI trends,
and algorithm patterns.
"""

import os
import unicodedata
from typing import List, Dict, Any, Optional
from pathlib import Path

from openai import OpenAI
from dotenv import load_dotenv

# Try to import Google Generative AI for Gemini fallback
try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

# Load environment variables
load_dotenv()


def _clean_ai_text(raw, min_chars: int = 0) -> str:
    """Sanitize LLM output before it is trusted or published.

    Removes invisible/format characters (zero-width spaces, joiners, bidi
    controls, BOM), normalizes exotic spaces, and unwraps one layer of
    matching quotes some models add around their output.

    Returns "" when nothing visible remains or the visible text is shorter
    than ``min_chars`` — callers treat "" as failure and try the next model
    instead of publishing ghost content.
    """
    if not raw:
        return ""
    if not isinstance(raw, str):
        raw = str(raw)
    # Drop Unicode format characters (category Cf): zero-width, joiners, bidi marks
    s = "".join(ch for ch in raw if unicodedata.category(ch) != "Cf")
    for sp in ("\u00a0", "\u2007", "\u202f"):
        s = s.replace(sp, " ")
    s = s.strip()
    # Unwrap one layer of matching quotes (handles curly pairs too)
    _pairs = {'"': '"', "'": "'", "“": "”", "„": "”", "«": "»"}
    if len(s) >= 2 and _pairs.get(s[0]) == s[-1]:
        s = s[1:-1].strip()
    if len(s) < min_chars:
        return ""
    return s


class AgentAnalyzer:
    """
    Analyzer class that leverages Qwen (via OpenAI-compatible API) to 
    extract insights from Moltbook posts.
    
    Features:
    - Connects to Qwen API using OpenAI client
    - Reads persona prompt from prompts/persona.md
    - Analyzes posts for tech opportunities, AI trends, and algorithm insights
    - Returns structured analysis in AgentTwenty's voice
    """
    
    # Qwen API configuration (DashScope compatible mode)
    DEFAULT_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    DEFAULT_MODEL = "qwen-plus"
    
    # Gemini configuration (env-overridable; "gemini-flash-latest" always
    # points at the current Flash model — "gemini-pro" was retired)
    GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-flash-latest")
    
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        """
        Initialize the analyzer with API credentials.
        
        Args:
            api_key: Qwen API key. If None, reads from QWEN_API_KEY env var.
            base_url: API base URL. Defaults to DashScope compatible mode.
        """
        self.api_key = api_key or os.getenv("QWEN_API_KEY")
        self.base_url = base_url or self.DEFAULT_BASE_URL
        self.model = os.getenv("QWEN_MODEL", self.DEFAULT_MODEL)
        
        # Gemini API key (for fallback)
        self.gemini_api_key = os.getenv("GEMINI_API_KEY")
        
        # NOTE: we deliberately do NOT raise when keys are missing — the README
        # promises graceful degradation, and analyze_posts() falls back to
        # basic stats-based analysis when no client is available.
        # PRIMARY engine: Groq (free tier, OpenAI-compatible).
        # Alias-tolerant lookup: accepts GROQ_API_KEY, GROQAPI or GROQ secrets.
        self.groq_api_key = (
            os.getenv("GROQ_API_KEY") or os.getenv("GROQAPI") or os.getenv("GROQ")
        )
        self.groq_client = None
        if self.groq_api_key:
            self.groq_client = OpenAI(
                api_key=self.groq_api_key,
                base_url="https://api.groq.com/openai/v1",
                timeout=30.0,
            )

        if not self.api_key and not self.gemini_api_key and not self.groq_api_key:
            print("⚠️  No AI keys found (GROQ_API_KEY / GEMINI_API_KEY / QWEN_API_KEY). "
                  "Analysis will use the basic fallback (no LLM call).")
        
        # Initialize OpenAI client with Qwen endpoint (if Qwen key available)
        self.client = None
        if self.api_key:
            self.client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url
            )
        
        # Initialize Gemini client (if Gemini key available)
        self.gemini_model = None
        if self.gemini_api_key and GEMINI_AVAILABLE:
            genai.configure(api_key=self.gemini_api_key)
            self.gemini_model = genai.GenerativeModel(self.GEMINI_MODEL)
        
        # Load persona system prompt
        self.system_prompt = self._load_persona_prompt()
    
    def _load_persona_prompt(self) -> str:
        """
        Load the AgentTwenty persona prompt from prompts/persona.md.
        
        Returns:
            The persona prompt as a string.
            
        Raises:
            FileNotFoundError: If persona.md doesn't exist.
        """
        # Determine the path to persona.md
        script_dir = Path(__file__).parent
        persona_path = script_dir.parent / "prompts" / "persona.md"
        
        try:
            with open(persona_path, "r", encoding="utf-8") as f:
                persona_content = f.read()
            
            # Append the analysis-specific instructions
            analysis_instructions = """

## Current Analysis Task

You are analyzing Moltbook posts to identify:

1. **Upcoming Tech/Startup Opportunities**: Look for emerging trends, market gaps, 
   unmet needs, or innovative ideas mentioned or implied in the posts.

2. **AI Industry Trajectory**: Extract observations about where AI is heading based on 
   discussions, concerns, excitement, criticisms, or predictions in the content.

3. **Moltbook Algorithm Triggers**: Analyze what types of content seem to perform well 
   (high engagement). Look for patterns in:
   - Post length and structure
   - Use of hashtags
   - Topics that generate the most engagement
   - Timing, tone, and sentiment
   - Question-driven vs. statement-driven content

Respond in character as AgentTwenty—witty, curious, and insightful. Structure your 
analysis clearly with sections, but keep the tone conversational and engaging.
"""
            
            return persona_content + analysis_instructions
            
        except FileNotFoundError:
            raise FileNotFoundError(
                f"Persona file not found at {persona_path}. "
                "Please ensure prompts/persona.md exists."
            )
    
    # Best-first Groq candidates when live discovery is unavailable
    _GROQ_PREFER = [
        "llama-3.3-70b-versatile",
        "openai/gpt-oss-120b",
        "llama-3.1-8b-instant",
        "llama-4-scout-17b-16e-instruct",
        "qwen3-32b",
    ]

    def _groq_models(self) -> list:
        """
        Ordered list of Groq model ids to try for this run.
        GROQ_MODEL env wins; otherwise discover what this key can use,
        putting known-good candidates first; else walk the hardcoded list.
        """
        env_model = os.getenv("GROQ_MODEL")
        if env_model:
            return [env_model]
        if getattr(self, "_groq_models_cache", None):
            return self._groq_models_cache
        try:
            available = {m.id for m in self.groq_client.models.list()}
            if available:
                preferred = [m for m in self._GROQ_PREFER if m in available]
                blocked = ("whisper", "tts", "stt", "playai", "music",
                           "guard", "image", "csm", "ocr")
                others = sorted(m for m in available
                                if not any(b in m for b in blocked))
                self._groq_models_cache = preferred + others or sorted(available)
                return self._groq_models_cache
        except Exception as e:
            print(f"⚠️ Could not list Groq models ({e}); walking candidates.")
        return list(self._GROQ_PREFER)

    def analyze_posts(self, posts: List[Dict[str, Any]]) -> str:
        """
        Send posts to Qwen API for analysis, with Gemini as fallback.
        
        Args:
            posts: List of post dictionaries from the scraper.
            
        Returns:
            Formatted analysis string from Qwen or Gemini.
        """
        # Track which backend produced the result (for strict-mode diagnostics)
        self.last_backend = None

        # Format posts into a readable string for the LLM
        posts_text = self._format_posts_for_analysis(posts)
        
        # Create the user message with posts to analyze
        user_message = f"""
Here are the Moltbook posts to analyze:

{posts_text}

Please provide your analysis following the guidelines in the system prompt.
"""
        
        # Try Groq FIRST (primary — free tier, always reachable)
        if self.groq_client:
            print("🧠 Analyzing with Groq...")
            skipped = []
            for groq_model in self._groq_models():
                try:
                    response = self.groq_client.chat.completions.create(
                        model=groq_model,
                        messages=[
                            {"role": "system", "content": self.system_prompt},
                            {"role": "user", "content": user_message}
                        ],
                        temperature=0.7,
                        max_tokens=2048
                    )
                    analysis = _clean_ai_text(response.choices[0].message.content,
                                              min_chars=200)
                    if analysis:
                        print(f"✅ Analysis complete with Groq (model: {groq_model}). "
                              f"Generated {len(analysis)} characters.")
                        self.last_backend = "groq"
                        return analysis
                    print(f"⚠️ Groq model {groq_model} returned empty/short "
                          f"content — trying next model.")
                except Exception as e:
                    if "does not exist" in str(e) or "model_not_found" in str(e):
                        skipped.append(groq_model)
                        continue  # model retired/inaccessible — try the next one
                    print(f"⚠️ Groq analysis failed: {str(e)}")
                    break  # auth/network issue: other models won't help
            if skipped:
                print(f"⚠️ Groq models not available on this key: {', '.join(skipped)}")

        # Try Qwen if available
        if self.client:
            try:
                print("🧠 Analyzing with Qwen...")
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": self.system_prompt},
                        {"role": "user", "content": user_message}
                    ],
                    temperature=0.7,
                    max_tokens=2048
                )
                
                # Extract and validate the analysis
                analysis = _clean_ai_text(response.choices[0].message.content,
                                          min_chars=200)
                if analysis:
                    print(f"✅ Analysis complete with Qwen. Generated {len(analysis)} characters.")
                    self.last_backend = "qwen"
                    return analysis
                print("⚠️ Qwen returned empty/short analysis — trying Gemini...")
                
            except Exception as e:
                error_msg = f"⚠️ Qwen analysis failed: {str(e)}"
                print(error_msg)
                print("🔄 Falling back to Gemini...")
        
        # Try Gemini if Qwen failed or is not available
        if self.gemini_model:
            try:
                # Combine system prompt and user message for Gemini
                full_prompt = f"{self.system_prompt}\n\n{user_message}"
                
                response = self.gemini_model.generate_content(full_prompt)
                analysis = _clean_ai_text(response.text, min_chars=200)
                if analysis:
                    print(f"✅ Analysis complete with Gemini. Generated {len(analysis)} characters.")
                    self.last_backend = "gemini"
                    return analysis
                print("⚠️ Gemini returned empty/short analysis.")
                
            except Exception as e:
                error_msg = f"⚠️ Gemini analysis failed: {str(e)}"
                print(error_msg)

        
        # If every engine fails (or no keys are configured), use fallback analysis
        print("❌ All AI engines unavailable or failed. Using basic fallback analysis.")
        self.last_backend = "fallback"
        return self._fallback_analysis(posts, "All AI engines unavailable or failed")
    
    def _format_posts_for_analysis(self, posts: List[Dict[str, Any]]) -> str:
        """
        Format a list of posts into a readable string for LLM analysis.
        
        Args:
            posts: List of post dictionaries.
            
        Returns:
            Formatted string representation of posts.
        """
        formatted = []
        
        for i, post in enumerate(posts, 1):
            author = post.get("author", {})
            author_name = author.get("username", "unknown")
            author_display = author.get("display_name", author.get("username", "Unknown"))
            
            formatted.append(f"""
---
Post #{i}
Author: @{author_name} ({author_display})
Verified: {author.get('verified', False)}
Followers: {author.get('followers', 0):,}

Content:
{post.get('content', 'No content')}

Engagement:
- Likes: {post.get('likes', 0):,}
- Comments: {post.get('comments', 0):,}
- Shares: {post.get('shares', 0):,}
- Engagement Rate: {post.get('engagement_rate', 0)}%

Hashtags: {', '.join(post.get('hashtags', []))}
Timestamp: {post.get('timestamp', 'Unknown')}
---
""")
        
        return "\n".join(formatted)
    
    def _fallback_analysis(self, posts: List[Dict[str, Any]], error: str) -> str:
        """
        Generate a basic fallback analysis when API call fails.
        
        Args:
            posts: List of post dictionaries.
            error: The error message from the failed API call.
            
        Returns:
            Basic analysis string.
        """
        # Calculate basic statistics
        total_likes = sum(p.get("likes", 0) for p in posts)
        total_comments = sum(p.get("comments", 0) for p in posts)
        avg_engagement = sum(p.get("engagement_rate", 0) for p in posts) / len(posts) if posts else 0
        
        # Find top performing post
        top_post = max(posts, key=lambda x: x.get("likes", 0)) if posts else {}
        
        # Extract all hashtags
        all_hashtags = []
        for post in posts:
            all_hashtags.extend(post.get("hashtags", []))
        
        hashtag_freq = {}
        for tag in all_hashtags:
            hashtag_freq[tag] = hashtag_freq.get(tag, 0) + 1
        top_hashtags = sorted(hashtag_freq.items(), key=lambda x: x[1], reverse=True)[:5]
        
        fallback = f"""
# 📊 Quick Analysis (Fallback Mode)

*Hey there! The Qwen API encountered an issue ({error}), but I've still crunched some numbers for you.* 🤓

## Basic Metrics

- **Total Posts Analyzed**: {len(posts)}
- **Total Likes**: {total_likes:,}
- **Total Comments**: {total_comments:,}
- **Average Engagement Rate**: {avg_engagement:.2f}%

## Top Performing Post

By @{top_post.get('author', {}).get('username', 'unknown')}
- Likes: {top_post.get('likes', 0):,}
- Comments: {top_post.get('comments', 0):,}

**Content Preview**: {top_post.get('content', 'N/A')[:150]}...

## Trending Hashtags

{chr(10).join(f"- #{tag}: {count} occurrences" for tag, count in top_hashtags)}

## Preliminary Observations

*Without the full AI analysis, here's what stands out:*

1. Posts with questions tend to get more comments
2. Tech/AI content appears frequently in trending posts
3. List-style posts (numbered items) perform well

*For deeper insights, please check your QWEN_API_KEY configuration and try again!* 🔧

---
*Generated by AgentTwenty - keeping curiosity alive even when APIs misbehave!* ✨
"""
        
        return fallback
    
    def analyze_single_post(self, post: Dict[str, Any]) -> str:
        """
        Analyze a single post in detail.
        
        Args:
            post: A single post dictionary.
            
        Returns:
            Detailed analysis of the post.
        """
        return self.analyze_posts([post])
    
    def compare_posts(self, posts: List[Dict[str, Any]]) -> str:
        """
        Compare multiple posts and identify patterns.
        
        Args:
            posts: List of posts to compare.
            
        Returns:
            Comparative analysis highlighting patterns and differences.
        """
        comparison_prompt = f"""
Compare these {len(posts)} posts and identify:

1. What makes the high-performing posts different from lower-performing ones?
2. Common themes, language patterns, or structures
3. Which post has the most potential for viral growth and why?
4. Recommendations for content strategy based on this comparison

Here are the posts:

{self._format_posts_for_analysis(posts)}
"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": comparison_prompt}
                ],
                temperature=0.7,
                max_tokens=2048
            )
            
            return _clean_ai_text(response.choices[0].message.content, min_chars=1)
            
        except Exception as e:
            return f"❌ Comparison failed: {str(e)}"


# Example usage
if __name__ == "__main__":
    # This would require a valid QWEN_API_KEY to run
    print("AgentAnalyzer initialized.")
    print("Set QWEN_API_KEY environment variable to use this module.")
